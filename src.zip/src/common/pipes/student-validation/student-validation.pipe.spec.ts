import { StudentValidationPipe } from './student-validation.pipe';

describe('StudentValidationPipe', () => {
  it('should be defined', () => {
    expect(new StudentValidationPipe()).toBeDefined();
  });
});
