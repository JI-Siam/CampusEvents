export class RegisterAdminDto {
  email: string;
  password: string;
}
