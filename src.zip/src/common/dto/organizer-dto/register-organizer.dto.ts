export class RegisterOrganizerDto {
  email: string;
  password: string;
}
